declare const wordlists: {
    [index: string]: string[];
};
declare let _default: string[] | undefined;
export { wordlists, _default };
